package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class appointments {

    private int appointment_ID;
    private String title;
    private String description;
    private String type;
    private LocalDateTime start;
    private LocalDateTime end;
    private LocalDateTime create_date;
    private String created_by;
    private Timestamp last_update;
    private String last_updated_by;
    private int customer_ID;
    private int user_ID;
    private int contact_ID;

    public appointments(int appointment_ID, String title, String description, String type, LocalDateTime start, LocalDateTime end, LocalDateTime create_date, String created_by, Timestamp last_update, String last_updated_by, int customer_ID, int user_ID, int contact_ID) {
        this.appointment_ID = appointment_ID;
        this.title = title;
        this.description = description;
        this.type = type;
        this.start = start;
        this.end = end;
        this.create_date = create_date;
        this.created_by = created_by;
        this.last_update = last_update;
        this.last_updated_by = last_updated_by;
        this.customer_ID = customer_ID;
        this.user_ID = user_ID;
        this.contact_ID = contact_ID;
    }

    public int getAppointment_ID() {
        return appointment_ID;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getType() {
        return type;
    }

    public LocalDateTime getStart() {
        return start;
    }

    public LocalDateTime getEnd() {
        return end;
    }

    public LocalDateTime getCreate_date() {
        return create_date;
    }

    public String getCreated_by() {
        return created_by;
    }

    public Timestamp getLast_update() {
        return last_update;
    }


    public String getLast_updated_by() {
        return last_updated_by;
    }

    public int getCustomer_ID() {
        return customer_ID;
    }

    public int getUser_ID() {
        return user_ID;
    }

    public int getContact_ID() {
        return contact_ID;
    }

}
