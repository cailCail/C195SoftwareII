package model;

public class contacts {
    private int contact_ID;
    private String contact_name;
    private String Email;

    public contacts(int contact_ID, String contact_name, String email) {
        this.contact_ID = contact_ID;
        this.contact_name = contact_name;
        Email = email;
    }

    public int getContact_ID() {
        return contact_ID;
    }

    public String getContact_name() {
        return contact_name;
    }

    public String getEmail() {
        return Email;
    }

}
