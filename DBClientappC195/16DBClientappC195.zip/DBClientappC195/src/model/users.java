package model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class users {

    private int user_ID;
    private String user_name;
    private String password;
    private LocalDateTime create_date;
    private String created_by;
    private Timestamp last_update;
    private String last_updated_by;

    public users(int user_ID, String user_name, String password, LocalDateTime create_date, String created_by, Timestamp last_update, String last_updated_by) {
        this.user_ID = user_ID;
        this.user_name = user_name;
        this.password = password;
        this.create_date = create_date;
        this.created_by = created_by;
        this.last_update = last_update;
        this.last_updated_by = last_updated_by;
    }

    public int getUser_ID() { return user_ID; }

    public String getUser_name() {
        return user_name;
    }

    public String getPassword() {
        return password;
    }

    public LocalDateTime getCreate_date() {
        return create_date;
    }

    public String getCreated_by() {
        return created_by;
    }

    public Timestamp getLast_update() {
        return last_update;
    }

    public String getLast_updated_by() {
        return last_updated_by;
    }

}
