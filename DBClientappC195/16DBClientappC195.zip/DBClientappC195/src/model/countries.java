package model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class countries {

    private int country_ID;
    private String country;


    public countries(int country_ID, String country) {
        this.country_ID = country_ID;
        this.country = country;
    }

    public int getCountry_ID() {
        return country_ID;
    }

    public String getCountry() {
        return country;
    }

    @Override
    public String toString(){
        return country_ID + "-" + country;
    }

}
