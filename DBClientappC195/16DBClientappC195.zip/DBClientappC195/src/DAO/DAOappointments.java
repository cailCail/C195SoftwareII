package DAO;

public class DAOappointments {
}
