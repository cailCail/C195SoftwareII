package DAO;

import Helper.JDBC;
import com.sun.javafx.charts.Legend;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import model.customer;
import model.first_level_divisions;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOcustomer {

    private static String Customer_Name;
    private static String Address;
    private static String Postal_Code;
    private static String Phone;
    private static int Division_ID;

    public static ObservableList<customer> getAllCustomers() {

        ObservableList<customer> customers = FXCollections.observableArrayList();
        try {
            String SQL = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, customers.Phone, first_level_divisions.Division_ID, first_level_divisions.Country_ID FROM customers INNER JOIN first_level_divisions ON first_level_divisions.Division_ID = customers.Division_ID";
            PreparedStatement pst = JDBC.getConnection().prepareStatement(SQL);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                int ID = rs.getInt("Customer_ID");
                String Name = rs.getString("Customer_Name");
                String Address = rs.getString("Address");
                String Zip = rs.getString("Postal_Code");
                String Phone = rs.getString("Phone");
                int Division = rs.getInt("Division_ID");
                int Country = rs.getInt("Country_ID");

                customer C = new customer(ID, Name, Address, Zip, Phone, Division, Country);
                customers.add(C);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        return customers;
    }
// method to create new customers
    public static void createCustomer(String name, String address, String zip, String phone, int division) {
        try {
            String insertCustomer = "INSERT INTO customers (Customer_Name, Address, Postal_Code, Phone, Division_ID) VALUES (?, ?, ?, ?, ?) ";
            PreparedStatement pst1 = JDBC.getConnection().prepareStatement(insertCustomer);
            pst1.setString(1, Customer_Name);
            pst1.setString(2, Address);
            pst1.setString(3, Postal_Code);
            pst1.setString(4, Phone);
            pst1.setInt(5, Division_ID);
            pst1.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
