package DAO;

import Helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.countries;
import model.customer;
import model.first_level_divisions;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOFirst_Level_Divisions {
    public static ObservableList<first_level_divisions> getAllfirst_level_divisions() {
        //public static ObservableList<first_level_divisions> getAllfirst_level_divisions(int Country_ID)
        ObservableList<first_level_divisions> FLDList = FXCollections.observableArrayList();
        try {
            String SQL = "SELECT * FROM first_level_divisions WHERE Country_ID; "; // QUESTION WHERE Country_ID = ?
                    //"SELECT * FROM first_level_divisions WHERE Country_ID = ?;";
            PreparedStatement pst = JDBC.getConnection().prepareStatement(SQL);

            //pst.setInt(1,Country_ID);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                int DivisionID = rs.getInt("Division_ID");
                String Division = rs.getString("Division");
                int Country = rs.getInt("Country_ID");

                first_level_divisions FLD = new first_level_divisions(DivisionID, Division, Country);
                FLDList.add(FLD);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        return FLDList;
    }
}


