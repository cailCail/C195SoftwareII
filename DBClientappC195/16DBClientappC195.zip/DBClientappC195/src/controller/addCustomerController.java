package controller;

import DAO.DAOFirst_Level_Divisions;
import DAO.DAOcountries;
import DAO.DAOcustomer;
import Helper.JDBC;
import com.mysql.cj.jdbc.JdbcConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.countries;
import model.customer;
import model.first_level_divisions;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class addCustomerController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private TextField addCustomerAddress;

    @FXML
    private ComboBox<countries> addCustomerCountry;

    @FXML
    private TextField addCustomerCustomerName;

    @FXML
    private TextField addCustomerCustomer_ID;

    @FXML
    private ComboBox<first_level_divisions> addCustomerFirst_Level_Division;

    @FXML
    private TextField addCustomerPhoneNumber;

    @FXML
    private TextField addCustomerPostalCode;

    @FXML
    private Button cancelBtnAddCustomer;

    @FXML
    private Button saveBtnAddCustomer;

// QUESTION
    @FXML
    void onActionAddCustomerCountry(ActionEvent event) {
        countries selectCountry = addCustomerCountry.getSelectionModel().getSelectedItem();

        ObservableList<String> unitedStatesCountry = FXCollections.observableArrayList();
        ObservableList<String> unitedKingdomCountry = FXCollections.observableArrayList();
        ObservableList<String> candaCountry = FXCollections.observableArrayList();

        // 1st I need to get the country ID that is selected by the customer then:
        // if selectCountry == Country_ID is 1 then use unitedStatesCountry observable array list in the first_level_divisions
        // if selectCountry == Country_ID is 2 then use unitedKingdomCountry then set observable list in the first-_level_divisions
        // if selectCountry == Country_ID is 3 then use candaCountry observable list in the first_level_divisions

        // this is the already created observable list for first level divisions in the DAO... not sure if i need this or not.
        // ObservableList<first_level_divisions> FLDList = FXCollections.observableArrayList();
       // selectCountry.getCountry_ID() == 1{
           // addCustomerFirst_Level_Division.setItems(unitedStatesCountry);

        }





    @FXML
    void onActionCancelAddCustomer(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/view/customer.fxml"));
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    void onActionCustomerFirst_Level_Division(ActionEvent event) {

    }
// QUESTION ADDING CUSTOMERS
    @FXML
    void onActionSaveAddCustomer(ActionEvent event) throws SQLException, IOException {

        String Name = addCustomerCustomerName.getText();
        String Address = addCustomerAddress.getText();
        String Zip = addCustomerPostalCode.getText();
        String Phone = addCustomerPhoneNumber.getText();
        int Division = (addCustomerFirst_Level_Division.getValue().getDivision_ID());

        DAOcustomer.createCustomer(Name, Address, Zip, Phone, Division);

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/view/customer.fxml"));
        stage.setScene(new Scene(root));
        stage.show();

//        String Name = addCustomerCustomerName.getText();
//        String Address = addCustomerAddress.getText();
//        String Zip = addCustomerPostalCode.getText();
//        String Phone = addCustomerPhoneNumber.getText();
//       int Division = (addCustomerFirst_Level_Division.getValue().getDivision_ID());
        //String country = (addCustomerCountry.getvalue().getDivision_ID());

     //   DAOcustomer.createCustomer(Name, Address, Zip, Phone, Division);
//        String insertCustomer = "INSERT INTO customers (Customer_Name, Address, Postal_Code, Phone, Division_ID) VALUES (?, ?, ?, ?, ?) ";
//        PreparedStatement pst1 = JDBC.getConnection().prepareStatement(insertCustomer);
//        pst1.setString(1,addCustomerCustomerName.getText());
//        pst1.setString(2, addCustomerAddress.getText());
//        pst1.setString(3, addCustomerPostalCode.getText());
//        pst1.setString(4, addCustomerPhoneNumber.getText());
//        pst1.setInt(5, addCustomerFirst_Level_Division.getValue().getDivision_ID());

//        DAOcustomer.createCustomer(String Name, String Address, String Zip, String Phone, int Division);
       // pst1.execute();

//        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
//        Parent root = FXMLLoader.load(getClass().getResource("/view/customer.fxml"));
//        stage.setScene(new Scene(root));
//        stage.show();


    }

    //DAOcustomer.getAllCustomers(new customers (id, Name,Address , Zip, Phone, Division, Country));
// insert watch key to keys or Malcom's video
//DAOcustomer.onActionSaveAddCustomer(Name, Address, Zip, Phone, Division.getID());

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        addCustomerCountry.setItems(DAOcountries.getAllCountries());
        addCustomerFirst_Level_Division.setItems(DAOFirst_Level_Divisions.getAllfirst_level_divisions());

//        addCustomerCountry.setItems(DAOcountries.getAllCountries());
//       addCustomerFirst_Level_Division.setItems(DAOFirst_Level_Divisions.getAllfirst_level_divisions());
        //addCustomerFirst_Level_Division.setItems(DAOFirst_Level_Divisions.getAllfirst_level_divisions(int Country_ID));
    }

}

