package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class mainApplicationController implements Initializable {

    Stage stage;
    Parent scene;


    @FXML
    private Button addBtnAppointment;

    @FXML
    private Button customerAppointmentsCustomerInformation;

    @FXML
    private Button deleteCustomerInformation;

    @FXML
    private Button exitCustomerInformation;

    @FXML
    private RadioButton radioBtnMonthCustomerInformation;

    @FXML
    private RadioButton radioBtnViewAllAppointments;

    @FXML
    private RadioButton radioBtnWeek;

    @FXML
    private ToggleGroup toggleCustomerInformation;

    @FXML
    private Button updateCustomerInformation;

    @FXML
    void onActionAddBtnAppointment(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/view/addAppointment.fxml"));
        stage.setScene(new Scene(root));
        stage.show();

    }

    @FXML
    void onActionDeleteCustomer(ActionEvent event) {

    }

    @FXML
    void onActionExit(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/view/mainMenu.fxml"));
        stage.setScene(new Scene(root));
        stage.show();

    }

    @FXML
    void onActionMonth(ActionEvent event) {

    }

    @FXML
    void onActionUpdateCustomer(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/view/updateAppointment.fxml"));
        stage.setScene(new Scene(root));
        stage.show();

    }

    @FXML
    void onActionViewAllAppointments(ActionEvent event) {

    }

    @FXML
    void onActionViewAllCustomers(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/view/customer.fxml"));
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    void onActionWeek(ActionEvent event) {

    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
