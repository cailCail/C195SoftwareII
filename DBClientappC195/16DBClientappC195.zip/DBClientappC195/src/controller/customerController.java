package controller;

import DAO.DAOcustomer;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.customer;
import model.first_level_divisions;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class customerController implements Initializable {

    Stage stage;
    Parent scene;

    public TableView<customer> customerTableView;
    
    @FXML
    private TableColumn<?, ?> Division_ID;

    @FXML
    private Button addBtnCustomer;

    @FXML
    private TableColumn<?, ?> customerAddress;

    @FXML
    private TableColumn<?, ?> customerCustomerName;

    @FXML
    private TableColumn<?, ?> customerCustomer_ID;

    @FXML
    private TableColumn<?, ?> customerPhoneNumber;

    @FXML
    private TableColumn<?, ?> customerPostalCode;

    @FXML
    private Button deleteBtnCustomer;

    @FXML
    private Button exitBtnCudtomer;

    @FXML
    private Button updateBtnCustomer;

    @FXML
    void anActionExitBtnCustomer(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/view/mainApplication.fxml"));
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    void onActionAddBtnCustomer(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/view/updateCustomer.fxml"));
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    void onActionDeleteBtnCustomer(ActionEvent event) {

    }

    @FXML
    void onActionUpdateBtnCustomer(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/view/updateCustomer.fxml"));
        stage.setScene(new Scene(root));
        stage.show();

    }

    @Override

        public void initialize (URL url, ResourceBundle resourceBundle){
        customerTableView.setItems(DAOcustomer.getAllCustomers());
        customerCustomer_ID.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        customerCustomerName.setCellValueFactory(new PropertyValueFactory<>("Customer_name"));
        customerAddress.setCellValueFactory(new PropertyValueFactory<>("Address"));
        customerPostalCode.setCellValueFactory(new PropertyValueFactory<>("Postal_code"));
        customerPhoneNumber.setCellValueFactory(new PropertyValueFactory<>("Phone"));
        Division_ID.setCellValueFactory(new PropertyValueFactory<>("Division_ID"));
    }


    }

