package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


public class customer {

    private int customer_ID;
    private String customer_name;
    private String address;
    private String postal_code;
    private String phone;
    private int division_ID;
    private int country_ID;

    public customer(int customer_ID, String customer_name, String address, String postal_code, String phone, int division_ID, int country_ID) {
        this.customer_ID = customer_ID;
        this.customer_name = customer_name;
        this.address = address;
        this.postal_code = postal_code;
        this.phone = phone;
        this.division_ID = division_ID;
        this.country_ID = country_ID;
    }

    public int getCustomer_ID() {
        return customer_ID;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public String getAddress() {
        return address;
    }

    public String getPostal_code() {
        return postal_code;
    }

    public String getPhone() {
        return phone;
    }

    public int getDivision_ID() {
        return division_ID;
    }

    public int getCountry_ID() {
        return country_ID;
    }
}

