package DAO;

import Helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.customer;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOcustomer {
    public static ObservableList<customer> getAllCustomers() {

        ObservableList <customer> customers = FXCollections.observableArrayList();
        try { String SQL = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, customers.Phone, first_level_divisions.Division_ID, first_level_divisions.Country_ID FROM customers INNER JOIN first_level_divisions ON first_level_divisions.Division_ID = customers.Division_ID";
            PreparedStatement pst = JDBC.getConnection().prepareStatement(SQL);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                int ID = rs.getInt("Customer_ID");
                String Name = rs.getString("Customer_Name");
                String Address = rs.getString("Address");
                String Zip = rs.getString("Postal_Code");
                String Phone = rs.getString("Phone");
                int Division = rs.getInt("Division_ID");
                int Country = rs.getInt("Country_ID");

                customer C = new customer (ID, Name, Address, Zip, Phone, Division, Country);
                customers.add(C);
            }
        }catch(SQLException e) {
            e.printStackTrace();
        }




        return customers;
    }
}
