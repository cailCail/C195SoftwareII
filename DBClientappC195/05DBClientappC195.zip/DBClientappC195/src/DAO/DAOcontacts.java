package DAO;

public class DAOcontacts {
}
