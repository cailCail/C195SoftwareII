package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class addAppointmentController {

    Stage stage;
    Parent scene;

    @FXML
    private ComboBox<?> addAppointmentLocation;

    @FXML
    private ComboBox<?> addContactAppointment;

    @FXML
    private TextField appointment_IDAddCustomer;

    @FXML
    private Button cancelBtnAddCustomer;

    @FXML
    private TextField customer_IDAddCustomer;

    @FXML
    private TextField descriptionAddCustomer;

    @FXML
    private ComboBox<?> endTimeAddAppointment;

    @FXML
    private Button saveBtnAddCustomer;

    @FXML
    private DatePicker startDateAddAppointment;

    @FXML
    private ComboBox<?> startTimeAddAppointment;

    @FXML
    private TextField titleAddCustomer;

    @FXML
    private ComboBox<?> typeAddAppointment;

    @FXML
    private TextField user_IDAddCustomer;

    @FXML
    void onActionAddAppointmentLocation(ActionEvent event) {

    }

    @FXML
    void onActionAddContactAppointment(ActionEvent event) {

    }

    @FXML
    void onActionCancelAddCustomer(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("/view/mainApplication.fxml"));
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    void onActionEndTimeAddAppointment(ActionEvent event) {

    }

    @FXML
    void onActionSaveAddCustomer(ActionEvent event) {

    }

    @FXML
    void onActionStartDateAddAppointment(ActionEvent event) {

    }

    @FXML
    void onActionStartTimeAddAppointment(ActionEvent event) {

    }

    @FXML
    void onActionTypeAddAppointment(ActionEvent event) {

    }
}